import {
  Component,
  OnInit,
  OnDestroy,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';
import {
  NonNullableFormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { ActivatedRoute } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';

import { AuctionService } from '../../auction/services/auction.service';
import { AuctionModel } from '../../auction/models/auction.model';

import { BidService } from '../../bid/services/bid.service';
import { WinnerService } from '../../winner/services/winner.service';

import { BidModel } from '../../bid/models/bid.model';
import { WinnerModel } from '../../winner/models/winner.model';

import { NotificationService } from '../../../core/services/notification.service';
import { WebSocketService } from '../../../core/services/websocket.service';

@Component({
  selector: 'app-crop-details',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatListModule
  ],
  templateUrl: './crop-details.html',
  styleUrl: './crop-details.scss'
})
export class CropDetails implements OnInit, OnDestroy {

  private fb = inject(NonNullableFormBuilder);
  private route = inject(ActivatedRoute);

  private auctionService = inject(AuctionService);
  private bidService = inject(BidService);
  private winnerService = inject(WinnerService);

  private notificationService = inject(NotificationService);
  private websocketService = inject(WebSocketService);

  auctionId = 0;

  auction?: AuctionModel;

  bids: BidModel[] = [];

  highestBid?: BidModel;

  winner?: WinnerModel;

  form = this.fb.group({
    amount: [0, [Validators.required, Validators.min(1)]]
  });

  ngOnInit(): void {

    this.auctionId = Number(
      this.route.snapshot.paramMap.get('id')
    );

    this.loadAuction();
    this.loadBids();
    this.loadHighestBid();
    this.loadWinner();

    this.connectWebSocket();

  }

  ngOnDestroy(): void {
    this.websocketService.disconnect();
  }

  loadAuction(): void {

    this.auctionService
      .getAuction(this.auctionId)
      .subscribe({

        next: response => {

          this.auction = response;

        },

        error: err => {

          this.notificationService.error(
            err.error?.message ??
            'Unable to load auction.'
          );

        }

      });

  }

  private connectWebSocket(): void {

    this.websocketService.connect();

    this.websocketService.subscribe(
      `/topic/auction/${this.auctionId}/bids`,
      () => {

        this.loadAuction();
        this.loadBids();
        this.loadHighestBid();

      }
    );

    this.websocketService.subscribe(
      `/topic/auction/${this.auctionId}/status`,
      () => {

        this.loadAuction();
        this.loadWinner();

      }
    );

  }

  placeBid(): void {

    if (this.form.invalid) {
      return;
    }

    this.bidService
      .placeBid(
        this.auctionId,
        this.form.getRawValue()
      )
      .subscribe({

        next: () => {

          this.notificationService.success(
            'Bid placed successfully.'
          );

          this.form.reset({
            amount: 0
          });

          this.loadAuction();
          this.loadBids();
          this.loadHighestBid();

        },

        error: err => {

          this.notificationService.error(
            err.error?.message ??
            'Unable to place bid.'
          );

        }

      });

  }

  loadBids(): void {

    this.bidService
      .getBids(this.auctionId)
      .subscribe({

        next: response => {

          this.bids = response.data;

        }

      });

  }

  loadHighestBid(): void {

    this.bidService
      .getHighestBid(this.auctionId)
      .subscribe({

        next: response => {

          this.highestBid = response.data;

        }

      });

  }

  loadWinner(): void {

    this.winnerService
      .getWinner(this.auctionId)
      .subscribe({

        next: response => {

          this.winner = response.data;

        }

      });

  }

}