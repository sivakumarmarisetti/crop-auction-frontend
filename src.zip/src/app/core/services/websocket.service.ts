import { Injectable } from '@angular/core';
import { Client, IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {

  private client!: Client;

  connect(): void {

    this.client = new Client({

      webSocketFactory: () =>
        new SockJS('http://localhost:8080/ws-auction'),

      reconnectDelay: 5000

    });

    this.client.activate();

  }

  subscribe(
    auctionId: number,
    callback: (message: any) => void
  ): void {

    if (!this.client.connected) {

      this.client.onConnect = () => {

        this.client.subscribe(

          `/topic/auction/${auctionId}`,

          (message: IMessage) => {

            callback(JSON.parse(message.body));

          }

        );

      };

      return;

    }

    this.client.subscribe(

      `/topic/auction/${auctionId}`,

      (message: IMessage) => {

        callback(JSON.parse(message.body));

      }

    );

  }

  disconnect(): void {

    if (this.client) {

      this.client.deactivate();

    }

  }

}